# Sentinel Core

A starter full-stack website security checker built with React + TypeScript and FastAPI.

## What it checks
- URL structure: HTTPS usage, IP-address host, username/password in URL, punycode hostname, unusual port, suspicious URL patterns.
- Public HTTP response: status code and selected security headers.
- HTTPS: validated TLS connection and certificate expiry when scanning an HTTPS URL.

## Safety design
- Only `http://` and `https://` URLs are accepted.
- DNS results are checked and non-public addresses are rejected.
- The backend connects to a validated IP address directly, rather than resolving the hostname again during connection.
- Redirects are not followed.
- Request and header-read timeouts/limits are enforced.
- This is a basic configuration checker, not a penetration tester and not a guarantee that a site is safe.

## Requirements
- Python 3.11+
- Node.js 20+ (includes npm)
- Windows 10 PowerShell

## 1. Start the backend
Open PowerShell in this folder:

```powershell
cd backend
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
```

If PowerShell blocks activation, run this for the current terminal only:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Backend runs at http://127.0.0.1:8000. API docs: http://127.0.0.1:8000/docs

## 2. Start the frontend
Open a second PowerShell window:

```powershell
cd frontend
npm install
npm run dev
```

Open the local URL Vite prints, usually http://localhost:5173.

## 3. Run backend tests
In the backend terminal (with its virtual environment active), open another terminal or stop the server, then:

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
python -m unittest discover -s tests -v
```

The tests cover URL validation and finding logic. They do not perform external scans.

## Troubleshooting
- `py` not found: install Python from python.org and enable “Add Python to PATH”.
- `npm` not found: install Node.js LTS, then reopen PowerShell.
- CORS errors: make sure backend is running on port 8000.
- Scan fails: some websites block automated requests, don't support the chosen protocol, or time out. That is reported as a scan error, not proof the site is malicious.
