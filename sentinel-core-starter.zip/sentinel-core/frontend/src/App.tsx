import { FormEvent, useMemo, useState } from "react";

type Finding = {
  id: string;
  title: string;
  severity: "critical" | "high" | "medium" | "low" | "info";
  description: string;
  evidence: string;
  recommendation: string;
};
type ScanResult = {
  target: string;
  scanned_at: string;
  status: string;
  http: { status_code: number; reason: string; headers_checked: number };
  network: { resolved_addresses: number; connected_address: string };
  tls: { checked: boolean; verified?: boolean; certificate_expiry?: string | null; message?: string };
  summary: { total_findings: number; counts: Record<string, number>; note: string };
  findings: Finding[];
};

const API_BASE = "http://127.0.0.1:8000";

function Icon({ name }: { name: string }) {
  const paths: Record<string, string> = {
    shield: "M12 22s8-4 8-11V5l-8-3-8 3v6c0 7 8 11 8 11Z",
    scan: "M3 7V5a2 2 0 0 1 2-2h2M17 3h2a2 2 0 0 1 2 2v2M21 17v2a2 2 0 0 1-2 2h-2M7 21H5a2 2 0 0 1-2-2v-2M3 12h18",
    globe: "M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20ZM2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z",
    activity: "M22 12h-4l-3 9L9 3l-3 9H2",
    file: "M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z M14 2v6h6 M8 13h8 M8 17h8",
    check: "m5 12 4 4L19 6",
    arrow: "M7 17 17 7M7 7h10v10",
    clock: "M12 8v4l3 2 M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0Z",
    lock: "M5 11h14v10H5z M8 11V7a4 4 0 1 1 8 0v4",
    alert: "M10.3 3.9 1.8 18.2A2 2 0 0 0 3.5 21h17a2 2 0 0 0 1.7-2.8L13.7 3.9a2 2 0 0 0-3.4 0ZM12 9v4M12 17h.01",
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d={paths[name] || paths.shield} /></svg>;
}

function severityClass(severity: string) {
  return `severity severity-${severity}`;
}

export default function App() {
  const [url, setUrl] = useState("https://example.com");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState("");
  const [activeFilter, setActiveFilter] = useState("all");

  const filteredFindings = useMemo(() => {
    if (!result) return [];
    return activeFilter === "all"
      ? result.findings
      : result.findings.filter((item) => item.severity === activeFilter);
  }, [result, activeFilter]);

  async function runScan(event: FormEvent) {
    event.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);
    setActiveFilter("all");
    try {
      const response = await fetch(`${API_BASE}/api/scan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url }),
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || "The scan could not be completed.");
      }
      setResult(data as ScanResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unexpected error. Check that the backend is running.");
    } finally {
      setLoading(false);
    }
  }

  function downloadReport() {
    if (!result) return;
    const blob = new Blob([JSON.stringify(result, null, 2)], { type: "application/json" });
    const objectUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = objectUrl;
    link.download = `sentinel-report-${new URL(result.target).hostname}.json`;
    link.click();
    URL.revokeObjectURL(objectUrl);
  }

  const dateLabel = result
    ? new Date(result.scanned_at).toLocaleString()
    : "Ready when you are";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Icon name="shield" /></div>
          <div><span className="brand-name">sentinel<span>.</span></span><small>CORE SECURITY</small></div>
        </div>
        <div className="side-label">WORKSPACE</div>
        <button className="nav-item active"><Icon name="scan" /> <span>Security scan</span><span className="nav-dot" /></button>
        <button className="nav-item" onClick={() => alert("Monitoring is planned for a later version. This button is not a live feature yet.")}><Icon name="activity" /> <span>Watchtower</span><span className="soon">SOON</span></button>
        <button className="nav-item" onClick={() => alert("Saved scan history is planned for a later version. Download reports to keep them for now.")}><Icon name="file" /> <span>Reports</span><span className="soon">SOON</span></button>
        <div className="sidebar-bottom">
          <div className="status-indicator"><span /> API status is checked on scan</div>
          <div className="version">SENTINEL CORE <span>v0.1.0</span></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar">
          <div className="breadcrumb">Workspace <span>/</span> <strong>Security scan</strong></div>
          <div className="topbar-right"><span className="env-pill"><i /> LOCAL ENVIRONMENT</span><div className="avatar">S</div></div>
        </header>

        <section className="page-heading">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" /> WEBSITE SECURITY INTELLIGENCE</div>
            <h1>See your security <span>clearly.</span></h1>
            <p>Run evidence-backed checks on a public website and turn technical signals into clear next steps.</p>
          </div>
          <div className="heading-badge"><Icon name="lock" /><span>DEFENSIVE<br />ANALYSIS</span></div>
        </section>

        <section className="scan-panel">
          <div className="panel-topline"><div className="panel-icon"><Icon name="globe" /></div><div><h2>New security scan</h2><p>Enter a public website you own or have permission to assess.</p></div><span className="live-label"><i /> READY</span></div>
          <form onSubmit={runScan}>
            <label htmlFor="target-url">TARGET URL</label>
            <div className="url-input-row">
              <div className="input-prefix"><Icon name="globe" /></div>
              <input id="target-url" type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://yourwebsite.com" required maxLength={2048} />
              <button className="scan-button" type="submit" disabled={loading}>{loading ? <><span className="spinner" /> Scanning</> : <><Icon name="scan" /> Run scan <span className="button-arrow">↗</span></>}</button>
            </div>
            <div className="form-footnote"><Icon name="lock" /> Public HTTP(S) only <span>·</span> No redirects followed <span>·</span> Limited configuration checks</div>
          </form>
        </section>

        {error && <div className="error-banner"><Icon name="alert" /><div><strong>Scan couldn't complete</strong><p>{error}</p></div></div>}

        {!result && !loading && !error && (
          <section className="empty-state">
            <div className="empty-graphic"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="empty-shield"><Icon name="shield" /></div><span className="orbit-point point-one" /><span className="orbit-point point-two" /><span className="orbit-point point-three" /></div>
            <h2>Your security overview starts here.</h2>
            <p>Run a scan to inspect public response headers, TLS connectivity, and selected URL characteristics.</p>
            <div className="empty-capabilities"><span><Icon name="check" /> Header checks</span><span><Icon name="check" /> TLS verification</span><span><Icon name="check" /> Evidence & fixes</span></div>
          </section>
        )}

        {loading && <section className="loading-state"><div className="loading-ring"><Icon name="shield" /></div><h2>Analyzing target</h2><p>Checking public DNS, connection security, and response headers…</p><div className="loading-track"><span /></div></section>}

        {result && (
          <section className="results-section">
            <div className="results-title-row"><div><div className="eyebrow"><span className="eyebrow-line" /> SCAN COMPLETE</div><h2>Security findings</h2><p className="scan-meta"><span className="success-dot" /> {result.target} <span>·</span> {dateLabel}</p></div><button className="secondary-button" onClick={downloadReport}><Icon name="file" /> Export JSON</button></div>
            <div className="metrics-grid">
              <div className="metric-card"><div className="metric-label">TOTAL FINDINGS <Icon name="activity" /></div><div className="metric-value">{result.summary.total_findings}<small> items</small></div><div className="metric-note">Evidence-backed observations</div></div>
              <div className="metric-card"><div className="metric-label">HIGH SEVERITY <Icon name="alert" /></div><div className="metric-value high-number">{result.summary.counts.high + result.summary.counts.critical}<small> items</small></div><div className="metric-note">Prioritize review</div></div>
              <div className="metric-card"><div className="metric-label">HTTP STATUS <Icon name="globe" /></div><div className="metric-value">{result.http.status_code}<small> {result.http.reason}</small></div><div className="metric-note">Root path response</div></div>
              <div className="metric-card"><div className="metric-label">TLS VERIFIED <Icon name="lock" /></div><div className={`metric-value ${result.tls.verified ? "good-number" : ""}`}>{result.tls.checked ? (result.tls.verified ? "Yes" : "No") : "N/A"}</div><div className="metric-note">{result.tls.checked ? (result.tls.certificate_expiry ? `Expires ${new Date(result.tls.certificate_expiry).toLocaleDateString()}` : "TLS handshake result") : "HTTP URL submitted"}</div></div>
            </div>
            <div className="findings-panel">
              <div className="findings-header"><div><h3>Findings & recommendations</h3><p>{result.summary.note}</p></div><span className="finding-count">{filteredFindings.length} SHOWN</span></div>
              <div className="filter-row">
                {["all", "critical", "high", "medium", "low", "info"].map((filter) => (
                  <button key={filter} className={`filter-chip ${activeFilter === filter ? "selected" : ""}`} onClick={() => setActiveFilter(filter)}>{filter === "all" ? "All findings" : filter[0].toUpperCase() + filter.slice(1)}{filter === "all" ? ` (${result.findings.length})` : ` (${result.summary.counts[filter] || 0})`}</button>
                ))}
              </div>
              <div className="findings-list">
                {filteredFindings.map((item) => (
                  <article className="finding-card" key={item.id}>
                    <div className={`finding-symbol ${item.severity}`}><Icon name={item.severity === "info" || item.severity === "low" ? "check" : "alert"} /></div>
                    <div className="finding-content"><div className="finding-title-row"><h4>{item.title}</h4><span className={severityClass(item.severity)}>{item.severity}</span></div><p>{item.description}</p><div className="evidence-box"><span>EVIDENCE</span><code>{item.evidence}</code></div><div className="recommendation"><strong>Recommended action</strong><p>{item.recommendation}</p></div></div>
                  </article>
                ))}
                {filteredFindings.length === 0 && <div className="no-findings">No findings at this severity in this scan.</div>}
              </div>
            </div>
          </section>
        )}

        <footer><span>© 2026 SENTINEL CORE</span><span>BUILT FOR CLARITY <b>·</b> NOT A COMPREHENSIVE SECURITY AUDIT</span></footer>
      </main>
    </div>
  );
}
