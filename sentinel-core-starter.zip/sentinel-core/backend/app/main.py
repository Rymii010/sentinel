from __future__ import annotations

import ipaddress
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urlsplit, unquote

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator

APP_VERSION = "0.1.0"
MAX_HEADER_BYTES = 32 * 1024
CONNECT_TIMEOUT = 4.0
READ_TIMEOUT = 4.0
TOTAL_TIMEOUT = 9.0

app = FastAPI(
    title="Sentinel Core API",
    description="Evidence-backed basic website configuration checks.",
    version=APP_VERSION,
)

# Local development only. Restrict this list to your deployed frontend origin before launch.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["Content-Type"],
)

class ScanRequest(BaseModel):
    url: str = Field(min_length=4, max_length=2048)

    @field_validator("url")
    @classmethod
    def validate_url(cls, value: str) -> str:
        value = value.strip()
        if any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
            raise ValueError("URL contains control characters.")
        parts = urlsplit(value)
        if parts.scheme.lower() not in ("http", "https"):
            raise ValueError("Only http:// and https:// URLs are supported.")
        if not parts.hostname:
            raise ValueError("Enter a valid URL with a hostname.")
        if parts.username is not None or parts.password is not None:
            raise ValueError("URLs containing usernames or passwords are not allowed.")
        if parts.port is not None and not (1 <= parts.port <= 65535):
            raise ValueError("Port must be between 1 and 65535.")
        if parts.fragment:
            # Fragments are never sent to a server; accept but remove during normalization.
            pass
        return value


def normalize_url(raw: str) -> tuple[str, str, int, str]:
    parts = urlsplit(raw.strip())
    scheme = parts.scheme.lower()
    hostname = (parts.hostname or "").rstrip(".").lower()
    try:
        port = parts.port or (443 if scheme == "https" else 80)
    except ValueError as exc:
        raise ValueError("Invalid port in URL.") from exc
    path = parts.path or "/"
    # We intentionally request only the origin root in this MVP. This avoids odd paths and
    # ensures query strings supplied by a user are not sent to a target.
    if not path.startswith("/") or "\r" in path or "\n" in path:
        path = "/"
    return scheme, hostname, port, path


def resolve_public_ips(hostname: str, port: int) -> list[str]:
    try:
        literal = ipaddress.ip_address(hostname)
        candidates = [str(literal)]
    except ValueError:
        try:
            infos = socket.getaddrinfo(hostname, port, type=socket.SOCK_STREAM)
        except socket.gaierror as exc:
            raise ValueError("The hostname could not be resolved.") from exc
        candidates = list(dict.fromkeys(info[4][0] for info in infos))

    if not candidates:
        raise ValueError("The hostname did not resolve to an IP address.")

    parsed = []
    for candidate in candidates:
        # Ignore IPv6 scope identifiers; public website scans should not use scoped addresses.
        candidate_clean = candidate.split("%", 1)[0]
        try:
            ip = ipaddress.ip_address(candidate_clean)
        except ValueError as exc:
            raise ValueError("The hostname resolved to an invalid IP address.") from exc
        if not ip.is_global:
            raise ValueError("Scanning private, local, reserved, or non-public IP addresses is blocked.")
        parsed.append(str(ip))
    return parsed


def fetch_headers_pinned(scheme: str, hostname: str, port: int, ip: str) -> tuple[int, str, dict[str, str], dict[str, Any] | None]:
    """Connect to a previously validated public IP, without redirects or a second DNS lookup."""
    started = time.monotonic()
    raw_sock = socket.create_connection((ip, port), timeout=CONNECT_TIMEOUT)
    tls_info = None
    sock: socket.socket = raw_sock
    try:
        if scheme == "https":
            context = ssl.create_default_context()
            # Keep certificate validation enabled.
            sock = context.wrap_socket(raw_sock, server_hostname=hostname)
            cert = sock.getpeercert()
            tls_info = {
                "verified": True,
                "subject": dict(x[0] for x in cert.get("subject", [])),
                "issuer": dict(x[0] for x in cert.get("issuer", [])),
                "not_after": cert.get("notAfter"),
            }
        sock.settimeout(READ_TIMEOUT)
        host_header = hostname if port in (80, 443) else f"{hostname}:{port}"
        request = (
            f"GET / HTTP/1.1\r\n"
            f"Host: {host_header}\r\n"
            f"User-Agent: SentinelCore/0.1 (+basic defensive configuration checks)\r\n"
            f"Accept: text/html,application/xhtml+xml,*/*;q=0.5\r\n"
            f"Connection: close\r\n\r\n"
        ).encode("ascii", errors="strict")
        sock.sendall(request)

        data = bytearray()
        while b"\r\n\r\n" not in data and len(data) < MAX_HEADER_BYTES:
            chunk = sock.recv(min(4096, MAX_HEADER_BYTES - len(data)))
            if not chunk:
                break
            data.extend(chunk)
            if time.monotonic() - started > TOTAL_TIMEOUT:
                raise TimeoutError("The target took too long to respond.")
        if b"\r\n\r\n" not in data:
            raise ValueError("The server did not return complete HTTP headers within the size limit.")

        header_block = bytes(data).split(b"\r\n\r\n", 1)[0].decode("iso-8859-1", errors="replace")
        lines = header_block.split("\r\n")
        match = re.match(r"^HTTP/\d(?:\.\d)?\s+(\d{3})(?:\s+(.*))?$", lines[0])
        if not match:
            raise ValueError("The server returned an unrecognized HTTP status line.")
        status = int(match.group(1))
        reason = (match.group(2) or "").strip()
        headers: dict[str, str] = {}
        for line in lines[1:]:
            if ":" not in line:
                continue
            name, value = line.split(":", 1)
            key = name.strip().lower()
            value = value.strip()
            if key and key not in headers:
                headers[key] = value
        return status, reason, headers, tls_info
    finally:
        try:
            sock.close()
        except Exception:
            pass
        if sock is not raw_sock:
            try:
                raw_sock.close()
            except Exception:
                pass


def finding(fid: str, title: str, severity: str, description: str, evidence: str, recommendation: str) -> dict[str, str]:
    return {
        "id": fid,
        "title": title,
        "severity": severity,
        "description": description,
        "evidence": evidence,
        "recommendation": recommendation,
    }


def analyze_url(raw: str) -> list[dict[str, str]]:
    parts = urlsplit(raw.strip())
    findings: list[dict[str, str]] = []
    scheme = parts.scheme.lower()
    host = (parts.hostname or "").lower()

    if scheme != "https":
        findings.append(finding(
            "url-https", "URL uses HTTP", "high",
            "The submitted URL uses unencrypted HTTP, so traffic to that URL is not protected by TLS.",
            f"Submitted scheme: {scheme}",
            "Use HTTPS and redirect HTTP traffic to HTTPS after verifying the site is configured correctly."
        ))
    else:
        findings.append(finding(
            "url-https", "HTTPS requested", "info",
            "The submitted URL uses HTTPS. The scan will separately verify whether the TLS connection succeeds.",
            "Submitted scheme: https",
            "Keep TLS certificates valid and renew them before expiry."
        ))

    try:
        ipaddress.ip_address(host)
        findings.append(finding(
            "url-ip-host", "URL uses an IP address", "low",
            "The URL uses an IP literal instead of a hostname. This can be legitimate, but is less typical for public websites.",
            f"Hostname: {host}",
            "If this is a public service, consider using a domain name with a correctly configured certificate."
        ))
    except ValueError:
        pass

    if host.startswith("xn--") or ".xn--" in host:
        findings.append(finding(
            "url-idn", "Internationalized hostname", "low",
            "The hostname contains a punycode label. This is not inherently malicious, but lookalike characters can be used in phishing.",
            f"Hostname: {host}",
            "Verify the domain spelling and ownership before entering credentials."
        ))

    if parts.port and parts.port not in (80, 443):
        findings.append(finding(
            "url-port", "Non-standard port", "info",
            "The URL specifies a port other than the usual HTTP/HTTPS ports.",
            f"Port: {parts.port}",
            "Confirm the port is expected for this service."
        ))

    decoded = unquote(parts.path + "?" + parts.query).lower()
    suspicious_patterns = [
        (r"(?:login|verify|signin|account).{0,30}(?:urgent|suspend|confirm|password)", "Credential-themed URL pattern"),
        (r"(?:bit\.ly|tinyurl\.com|t\.co)/", "URL contains a known short-link pattern"),
        (r"%[0-9a-f]{2}", "URL contains percent-encoded characters"),
    ]
    for pattern, label in suspicious_patterns:
        if re.search(pattern, decoded):
            findings.append(finding(
                "url-pattern-" + str(len(findings)), label, "low",
                "This URL characteristic can occur in legitimate links too; it is a review signal, not a malware verdict.",
                f"Matched rule: {label}",
                "Check the full destination domain independently before opening the link or submitting sensitive information."
            ))

    return findings


SECURITY_HEADERS = [
    ("content-security-policy", "Content-Security-Policy", "medium",
     "Helps limit which scripts and other resources a browser may load.",
     "Configure a policy appropriate to the site's actual resources; test in report-only mode first if needed."),
    ("strict-transport-security", "Strict-Transport-Security", "medium",
     "Tells browsers to use HTTPS for future visits.",
     "If the site is HTTPS-only and correctly configured, consider a suitable HSTS policy."),
    ("x-content-type-options", "X-Content-Type-Options", "low",
     "Helps prevent browsers from MIME-sniffing a response away from its declared content type.",
     "Set X-Content-Type-Options: nosniff where appropriate."),
    ("referrer-policy", "Referrer-Policy", "low",
     "Controls how much referrer information browsers send to other sites.",
     "Choose a privacy-conscious policy such as strict-origin-when-cross-origin if suitable."),
    ("permissions-policy", "Permissions-Policy", "info",
     "Can restrict use of selected browser features.",
     "Set a policy for browser features the site does not need."),
    ("x-frame-options", "X-Frame-Options", "low",
     "Can help prevent unwanted framing in browsers; CSP frame-ancestors is the modern flexible option.",
     "Set an appropriate X-Frame-Options header or CSP frame-ancestors directive."),
]


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "sentinel-core", "version": APP_VERSION}


@app.post("/api/scan")
def scan(request: ScanRequest) -> dict[str, Any]:
    started_at = datetime.now(timezone.utc).isoformat()
    try:
        scheme, hostname, port, _path = normalize_url(request.url)
        url_findings = analyze_url(request.url)
        ips = resolve_public_ips(hostname, port)
        # Pin the connection to one already-validated address; do not follow redirects.
        status, reason, headers, tls_info = fetch_headers_pinned(scheme, hostname, port, ips[0])

        findings = list(url_findings)
        for header, display, severity, description, recommendation in SECURITY_HEADERS:
            if header not in headers:
                # HSTS is meaningful only on HTTPS responses.
                if header == "strict-transport-security" and scheme != "https":
                    continue
                findings.append(finding(
                    "missing-" + header, f"Missing {display}", severity,
                    description,
                    f"{display} was not present in the HTTP response headers.",
                    recommendation
                ))

        if status >= 500:
            findings.append(finding(
                "http-server-error", "Server returned an error", "medium",
                "The server returned a 5xx status code for the root path.",
                f"HTTP status: {status} {reason}".strip(),
                "Check server logs and application health. A single response may be transient."
            ))
        elif status >= 400:
            findings.append(finding(
                "http-client-error", "Root path returned an error", "info",
                "The root path returned a 4xx response. Some sites intentionally restrict automated requests.",
                f"HTTP status: {status} {reason}".strip(),
                "Confirm whether this response is expected for the public homepage."
            ))

        cert_expiry = None
        if tls_info and tls_info.get("not_after"):
            try:
                expiry = datetime.strptime(tls_info["not_after"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
                cert_expiry = expiry.isoformat()
                days_left = (expiry - datetime.now(timezone.utc)).days
                if days_left < 0:
                    findings.append(finding(
                        "tls-expired", "TLS certificate expired", "high",
                        "The TLS certificate presented by the server is expired.",
                        f"Certificate expiry: {cert_expiry}",
                        "Renew and deploy a valid certificate."
                    ))
                elif days_left <= 21:
                    findings.append(finding(
                        "tls-expiring", "TLS certificate expires soon", "medium",
                        "The TLS certificate is nearing its expiry date.",
                        f"Certificate expiry: {cert_expiry}; approximately {days_left} days remaining.",
                        "Renew the certificate before expiry and verify automatic renewal."
                    ))
            except (ValueError, TypeError):
                # A certificate with an unexpected date format should not crash the scan.
                cert_expiry = None
        if scheme == "http":
            tls_summary = {"checked": False, "message": "TLS was not tested because the submitted URL uses HTTP."}
        else:
            tls_summary = {"checked": True, "verified": bool(tls_info), "certificate_expiry": cert_expiry}

        # A simple summary only; do not imply a comprehensive or predictive safety score.
        severity_rank = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        counts = {level: sum(1 for item in findings if item["severity"] == level)
                  for level in ("critical", "high", "medium", "low", "info")}
        return {
            "target": f"{scheme}://{hostname}" + (f":{port}" if port not in (80, 443) else ""),
            "scanned_at": started_at,
            "status": "completed",
            "http": {"status_code": status, "reason": reason, "headers_checked": len(headers)},
            "network": {"resolved_addresses": len(ips), "connected_address": ips[0]},
            "tls": tls_summary,
            "summary": {
                "total_findings": len(findings),
                "counts": counts,
                "note": "This is a limited configuration review, not a verdict that the website is safe or unsafe."
            },
            "findings": sorted(findings, key=lambda item: severity_rank.get(item["severity"], 0), reverse=True),
        }
    except (ValueError, TimeoutError, socket.timeout, socket.gaierror, ssl.SSLError, OSError) as exc:
        # Do not leak stack traces or internal details to the client.
        message = str(exc)
        if isinstance(exc, ssl.SSLError):
            message = "TLS negotiation or certificate validation failed. The certificate may be invalid, or the server may not support the requested connection."
        elif isinstance(exc, (socket.timeout, TimeoutError)):
            message = "The server timed out before the scan could complete."
        raise HTTPException(status_code=422, detail=message) from None
