import unittest
from pydantic import ValidationError

from app.main import ScanRequest, analyze_url, normalize_url


class URLValidationTests(unittest.TestCase):
    def test_accepts_https_url(self):
        req = ScanRequest(url="https://example.com/path")
        self.assertEqual(req.url, "https://example.com/path")

    def test_rejects_unsupported_scheme(self):
        with self.assertRaises(ValidationError):
            ScanRequest(url="file:///C:/Windows/win.ini")

    def test_rejects_credentials(self):
        with self.assertRaises(ValidationError):
            ScanRequest(url="https://user:pass@example.com")

    def test_rejects_control_characters(self):
        with self.assertRaises(ValidationError):
            ScanRequest(url="https://example.com/\r\nHost: localhost")

    def test_normalizes_missing_path(self):
        self.assertEqual(normalize_url("https://example.com")[3], "/")

    def test_http_is_flagged(self):
        findings = analyze_url("http://example.com")
        self.assertTrue(any(f["id"] == "url-https" and f["severity"] == "high" for f in findings))

    def test_https_is_not_claimed_safe(self):
        findings = analyze_url("https://example.com")
        self.assertTrue(any(f["id"] == "url-https" and f["severity"] == "info" for f in findings))
        self.assertFalse(any("safe" in f["title"].lower() for f in findings))


if __name__ == "__main__":
    unittest.main()
